Rainfall Prediction Project

Steps:
1. Install dependencies:
   pip install pandas numpy scikit-learn

2. Run the script:
   python rainfall_prediction.py

Dataset: weather_data.csv
