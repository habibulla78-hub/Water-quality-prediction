import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

# Load dataset
data = pd.read_csv("weather_data.csv")

# Features and target
X = data[['temperature', 'humidity', 'wind_speed', 'pressure']]
y = data['rainfall']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model
model = LinearRegression()
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Evaluation
error = mean_absolute_error(y_test, y_pred)
print("Mean Absolute Error:", error)

# New prediction
new_data = np.array([[30, 70, 10, 1012]])
prediction = model.predict(new_data)
print("Predicted Rainfall:", prediction[0])
